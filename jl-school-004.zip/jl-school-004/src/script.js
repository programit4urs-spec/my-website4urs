// -----------------------
// Dark Mode
// -----------------------
document.getElementById("darkToggle").onclick = function() {
    document.body.classList.toggle("dark");
};

// -----------------------
// Reveal Animation
// -----------------------
const reveals = document.querySelectorAll(".language");
window.addEventListener("scroll", () => {
    reveals.forEach(r => {
        const top = r.getBoundingClientRect().top;
        if (top < window.innerHeight - 100) {
            r.classList.add("show");
        }
    });
});

// -----------------------
// Counters
// -----------------------
const counters = document.querySelectorAll(".counter");
counters.forEach(counter => {
    counter.innerText = "0";
    const update = () => {
        const target = +counter.getAttribute("data-target");
        const c = +counter.innerText;
        const inc = target / 100;
        if (c < target) {
            counter.innerText = Math.ceil(c + inc);
            setTimeout(update, 20);
        } else {
            counter.innerText = target;
        }
    };
    update();
});

// -----------------------
// Payment Modal
// -----------------------
document.querySelectorAll(".payBtn").forEach(btn => {
    btn.onclick = () => {
        document.getElementById("paymentModal").style.display = "flex";
    }
});

function closeModal() {
    document.getElementById("paymentModal").style.display = "none";
}

// -----------------------
// EmailJS Integration
// -----------------------

// Make sure you have included this in your HTML before this script:
// <script src="https://cdn.emailjs.com/sdk/3.2.0/email.min.js"></script>

// Initialize EmailJS with your User ID
emailjs.init("user_n2HvigrcnziFHg5w9");

// Form Submission
document.getElementById("form").addEventListener("submit", function(e) {
    e.preventDefault();

    emailjs.sendForm('service_yqqfg6n', 'template_kvmpghi', this)
        .then(function() {
            alert("Registration Successful! 🎉 We will contact you soon.");
            document.getElementById("form").reset(); // clear form
        }, function(error) {
            alert("Oops... Something went wrong ❌ " + JSON.stringify(error));
        });
});
